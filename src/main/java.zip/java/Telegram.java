
public class Telegram {

}
