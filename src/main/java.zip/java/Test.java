import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class Test {
	public static String token = "444d3b1bf10a6602ac321e64ad68066ab4ab8fae50e2cfbe066f7a95eff2b21c";
	
	public static void main(String[] args) {
		String url = "https://opendata-ajuntament.barcelona.cat";
		String path = "data/dataset/6aa3416d-ce1a-494d-861b-7bd07f069600/resource/1b215493-9e63-4a12-8980-2d7e0fa19f85/download";
		Client client = ClientBuilder.newClient();
	
		WebTarget targetGet = client.target(url).path(path);
		
		Data response = targetGet.request(MediaType.APPLICATION_JSON_TYPE).header("Authorization", token).get(new GenericType<Data>() {});
		
//		System.out.println(response.getData().getStations().get(0).getStation_id());
		System.out.println(response);
		
		//Response response = targetGet.request(MediaType.APPLICATION_JSON_TYPE).header("Authorization", token).get();
		//System.out.println(response);
		
	}
}
