
public class Waqi {

}
